// import mongoose from "mongoose";

// const connectToMongo = async () => {
//   const res = await mongoose.connect(
//     "mongodb://localhost:27017/mern-gallery-app"
//   );
//   if (res) {
//     console.log("Connected Succesffuly");
//   }
// };

// export default connectToMongo;


// chatGPT code starts here
import mongoose from "mongoose";

const connectToMongo = async () => {
  try {
    await mongoose.connect("mongodb://localhost:27017/mern-gallery-app");
    console.log("Connected Successfully");
  } catch (error) {
    console.error("Connection Error:", error.message);
  }
};

export default connectToMongo;

